from flask import Flask,request,jsonify
from flasgger import Swagger

app= Flask(__name__)
swagger=Swagger(app)

#in memory data store
user_data={}

@app.route('/put_user/<int:user_id>',methods=['PUT'])
def put_user(user_id):
    """
    Update user data.

    ---
    parameters:
      - name: user_id
        in: path
        type: integer
        required: true
        description: The ID of the user
      - name: data
        in: body
        required: true
        schema:
          properties:
            name:
              type: string
              description: the name of the user
            age:
              type: integer
              description: the age of the user
    responses:
     200:
        description: This message says user updated successfully

    """
    try:
        data= request.json

        user_data[user_id]= data

        return jsonify({'message': f'Data for user {user_id} is updated'}), 200
    except Exception as e:
        return jsonify({'error':f'user not found : {str(e)}'}), 500


if __name__=='__main__':
    app.run(debug=True)