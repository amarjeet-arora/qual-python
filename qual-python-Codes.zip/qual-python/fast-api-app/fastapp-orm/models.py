from sqlalchemy import Column, Integer, String
from sqlalchemy.sql.expression import text
from database import Base

class Student(Base):
    __tablename__="STUDENT"

    name=Column(String,primary_key=True,nullable=False)
    sclass=Column(String,nullable=False)
    section=Column(String,nullable=False)